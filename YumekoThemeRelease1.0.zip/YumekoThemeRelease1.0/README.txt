YUMEKO THEME 1.0 FOR BANDAGEDBD

          _____
         |A .  | _____
         | /.\ ||A ^  | _____
         |(_._)|| / \ ||A _  | _____
         |  |  || \ / || ( ) ||A_ _ |
         |____V||  .  ||(_'_)||( v )|
                |____V||  |  || \ / |
                       |____V||  .  |
                              |____V|

Developed by Yumeko#7632

Source: NotAnotherAnimeTheme by puckzxz#2080. Big thanks
to them for making this possible!

Instructions:
***INSTALL***
1. Make sure BandagedBD is installed.
2. Move the .css file into the "themes" folder
(accessible by the "themes" menu in the BandagedBD
settings)
3. You're done! Simply enable the theme to use it!

***UPDATE***
1. If there is an update posted on the Support Server,
download the new file.
2. After downloading, move the new file to the "themes"
folder.
3. Delete the old file, and you're done!

***UNINSTALL***
1. Go to the "themes" folder.
2. Delete the .css file (YumekoThemeDev/ReleaseX.X) and
you're done!